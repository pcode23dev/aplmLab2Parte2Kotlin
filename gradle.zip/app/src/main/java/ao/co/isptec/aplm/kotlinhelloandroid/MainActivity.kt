package ao.co.isptec.aplm.kotlinhelloandroid

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import android.util.Log
import ao.co.isptec.aplm.kotlinhelloandroid.ui.theme.KotlinHelloAndroidTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        Log.d("MainActivity", "onCreate")
        var nome :String? = null
        var nomeF = nome?:  "Usuario Desconhecido"
        val idade = 20
        var idadeV = if(idade > 18) { "Maior de idade" } else { "Menor de idade" }
        val opc = 1
        var msg = when(opc) {
            1 -> "Opcao 1"
            2 -> "Opcao 2"
            else -> "Opcao desconhecida"
        }
        Log.d("MainActivity", "Nome: $nomeF, Idade: $idadeV, Opcao: $msg")
        setContent {
            KotlinHelloAndroidTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    Greeting(
                        name = "Android",
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    KotlinHelloAndroidTheme {
        Greeting("Android")
    }
}